import { useState } from 'react'
import './App.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LandingPage from './pages/Landing/Landing.jsx'
import TeacherLogin from './auth/TeacherAuth/TeacherLogin.jsx';
import TeacherSignup from './auth/TeacherAuth/TeacherSignup.jsx';
import AcademyPage from './academy/AcademyStuff/Page.jsx';
import StudentLogin from './auth/StudentAuth/StudentLogin.jsx';
import TeacherDashboard from './dashboard/DashFinal.jsx';
import TeacherExamMonitoring from './dashboard/TeacherExamMonitoring.jsx';
import StudentExamDetails from './dashboard/StudentExamDetails.jsx';
import ExamPage from './exam/ExamPage.jsx';
import NotFound from './common/NotFound/NotFound.jsx';
import Footer from './common/Footer/Footer.jsx';

function App() {

  return (

    <BrowserRouter>
      {/* <Navbar /> */}

      <Routes>
        {/* Landing */}
        <Route path="/" element={<LandingPage />} />

        {/* Teacher auth */}
        <Route path="/login" element={<TeacherLogin />} />
        <Route path="/signup" element={<TeacherSignup />} />

        {/* Academy public */}
        <Route path="/:academySlug" element={<AcademyPage />} />

        {/* Student / Teacher under academy */}
        <Route path="/:academySlug/login" element={<StudentLogin />} />
        <Route path="/:academySlug/dashboard" element={<TeacherDashboard />} />
        <Route path="/:academySlug/dashboard/exams/:examId" element={<TeacherExamMonitoring />} />
        <Route path="/:academySlug/dashboard/exams/:examId/student/:studentId" element={<StudentExamDetails />} />
        <Route
          path="/:academySlug/exam/:examId"
          element={<ExamPage />}
        />

        {/* Fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>

      <Footer />
    </BrowserRouter>

  );
}

export default App
