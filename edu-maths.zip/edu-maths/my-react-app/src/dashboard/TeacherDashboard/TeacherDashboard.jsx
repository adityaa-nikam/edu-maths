import React from 'react';
import { useParams } from 'react-router-dom';

const TeacherDashboard = () => {
  const { academySlug } = useParams();

  return (
    <div style={{ minHeight: 'calc(100vh - 200px)', backgroundColor: 'var(--bg-secondary)' }}>
      {/* Dashboard Header */}
      <div style={{
        background: 'linear-gradient(135deg, var(--primary-purple), var(--accent-pink))',
        padding: 'var(--spacing-3xl) var(--spacing-md)',
        color: 'white'
      }}>
        <div className="container">
          <h1 style={{
            fontSize: '2rem',
            fontWeight: '700',
            marginBottom: 'var(--spacing-sm)'
          }}>
            Welcome, Teacher! 👋
          </h1>
          <p style={{ fontSize: '1.125rem', opacity: '0.9' }}>
            Managing: <strong style={{ textTransform: 'capitalize' }}>{academySlug}</strong> Academy
          </p>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="py-6">
        <div className="container">
          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {/* Students Card */}
            <div className="card stagger-item">
              <div className="flex items-center gap-3 mb-3">
                <div style={{
                  width: '3rem',
                  height: '3rem',
                  borderRadius: 'var(--radius-lg)',
                  background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '1.5rem'
                }}>
                  👥
                </div>
                <div>
                  <h3 style={{
                    fontSize: '2rem',
                    fontWeight: '700',
                    color: 'var(--text-primary)',
                    marginBottom: '0'
                  }}>
                    0
                  </h3>
                </div>
              </div>
              <h4 style={{
                fontSize: '1.125rem',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: 'var(--spacing-xs)'
              }}>
                Students
              </h4>
              <p style={{
                color: 'var(--text-secondary)',
                fontSize: '0.875rem',
                margin: '0'
              }}>
                Manage your students
              </p>
            </div>

            {/* Exams Card */}
            <div className="card stagger-item">
              <div className="flex items-center gap-3 mb-3">
                <div style={{
                  width: '3rem',
                  height: '3rem',
                  borderRadius: 'var(--radius-lg)',
                  background: 'linear-gradient(135deg, var(--primary-purple), var(--accent-pink))',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '1.5rem'
                }}>
                  📝
                </div>
                <div>
                  <h3 style={{
                    fontSize: '2rem',
                    fontWeight: '700',
                    color: 'var(--text-primary)',
                    marginBottom: '0'
                  }}>
                    0
                  </h3>
                </div>
              </div>
              <h4 style={{
                fontSize: '1.125rem',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: 'var(--spacing-xs)'
              }}>
                Exams
              </h4>
              <p style={{
                color: 'var(--text-secondary)',
                fontSize: '0.875rem',
                margin: '0'
              }}>
                Create and manage exams
              </p>
            </div>

            {/* Results Card */}
            <div className="card stagger-item">
              <div className="flex items-center gap-3 mb-3">
                <div style={{
                  width: '3rem',
                  height: '3rem',
                  borderRadius: 'var(--radius-lg)',
                  background: 'linear-gradient(135deg, var(--accent-teal), #0d9488)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '1.5rem'
                }}>
                  📊
                </div>
                <div>
                  <h3 style={{
                    fontSize: '2rem',
                    fontWeight: '700',
                    color: 'var(--text-primary)',
                    marginBottom: '0'
                  }}>
                    0
                  </h3>
                </div>
              </div>
              <h4 style={{
                fontSize: '1.125rem',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: 'var(--spacing-xs)'
              }}>
                Results
              </h4>
              <p style={{
                color: 'var(--text-secondary)',
                fontSize: '0.875rem',
                margin: '0'
              }}>
                View exam results
              </p>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="card animate-fade-in">
            <h2 style={{
              fontSize: '1.5rem',
              fontWeight: '700',
              marginBottom: 'var(--spacing-md)',
              color: 'var(--text-primary)'
            }}>
              Recent Activity
            </h2>
            <div style={{
              textAlign: 'center',
              padding: 'var(--spacing-3xl) var(--spacing-xl)',
              color: 'var(--text-muted)'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: 'var(--spacing-md)' }}>
                📋
              </div>
              <p style={{ fontSize: '1rem' }}>
                No recent activity yet. Start by creating your first exam or adding students.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;

