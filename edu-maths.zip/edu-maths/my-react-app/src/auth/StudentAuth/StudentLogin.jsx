import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import studentAPI from '../../api/studentAPI';
import authStorage from '../../utils/authStorage';

const StudentLogin = () => {
  const { academySlug } = useParams();
  const navigate = useNavigate();

  // Form state
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Validate academySlug exists
      if (!academySlug) {
        setError('Invalid academy');
        setLoading(false);
        return;
      }

      // Validate inputs
      if (!username.trim() || !password.trim()) {
        setError('Please fill in all fields');
        setLoading(false);
        return;
      }

      // Call backend API using studentAPI
      const data = await studentAPI.login(academySlug, username.trim(), password);

      // Store token and student info using authStorage
      authStorage.setToken(data.token);
      authStorage.setStudentData(data.student);

      // Redirect to academy page (NOT dashboard - that's for teachers)
      navigate(`/${academySlug}`);
      
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to login. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="container container--sm">
        <div className="card animate-fade-in">
          {/* Academy Badge */}
          <div className="text-center mb-4">
            <span style={{
              display: 'inline-block',
              padding: '0.5rem 1rem',
              backgroundColor: 'var(--neutral-100)',
              color: 'var(--primary-purple)',
              borderRadius: 'var(--radius-lg)',
              fontSize: '0.875rem',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.05em'
            }}>
              🎓 {academySlug}
            </span>
          </div>

          {/* Page Title */}
          <h1 className="page-title">Student Login</h1>
          <p className="page-subtitle">Sign in to access your exams</p>

          {/* Error Message */}
          {error && (
            <div style={{
              padding: '1rem',
              backgroundColor: '#fee',
              border: '1px solid #fcc',
              borderRadius: '0.5rem',
              color: '#c33',
              marginBottom: '1.5rem',
              fontSize: '0.875rem'
            }}>
              {error}
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit}>
            {/* Username Field */}
            <div className="form-group">
              <label htmlFor="username" className="form-label">
                Username
              </label>
              <input
                type="text"
                className="form-input"
                id="username"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
                required
              />
            </div>

            {/* Password Field */}
            <div className="form-group">
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className="form-input"
                id="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
                required
              />
            </div>

            {/* Submit Button */}
            <button 
              type="submit" 
              className="btn btn-primary btn-full mt-4"
              disabled={loading}
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>

          {/* Back to Academy Link */}
          <div className="text-center mt-5" style={{
            borderTop: '1px solid var(--neutral-200)',
            paddingTop: 'var(--spacing-lg)'
          }}>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
              <Link to={`/${academySlug}`} className="link">
                ← Back to Academy Page
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentLogin;
