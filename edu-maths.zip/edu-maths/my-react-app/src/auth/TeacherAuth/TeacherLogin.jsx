import React from 'react';
import { SignIn } from '@clerk/clerk-react';

const TeacherLogin = () => {
  return (
    <div className="page-container">
      <div className="container container--sm">
        <div className="card animate-fade-in" style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          padding: 'var(--spacing-2xl)'
        }}>
          {/* Page Title */}
          <h1 className="page-title" style={{ textAlign: 'center' }}>Teacher Login</h1>
          <p className="page-subtitle" style={{ textAlign: 'center', marginBottom: 'var(--spacing-xl)' }}>
            Welcome back! Sign in to your account
          </p>

          {/* Clerk Sign In Component */}
          <SignIn
            routing="path"
            path="/login"
            signUpUrl="/signup"
            fallbackRedirectUrl="/dashboard"
            appearance={{
              elements: {
                rootBox: {
                  width: '100%',
                },
                card: {
                  boxShadow: 'none',
                  border: 'none',
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default TeacherLogin;
