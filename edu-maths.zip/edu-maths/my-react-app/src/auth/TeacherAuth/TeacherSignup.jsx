import React from 'react';
import { SignUp } from '@clerk/clerk-react';

const TeacherSignup = () => {
  return (
    <div className="page-container">
      <div className="container container--sm">
        <div className="card animate-fade-in" style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          padding: 'var(--spacing-2xl)'
        }}>
          {/* Page Title */}
          <h1 className="page-title" style={{ textAlign: 'center' }}>Create Your Account</h1>
          <p className="page-subtitle" style={{ textAlign: 'center', marginBottom: 'var(--spacing-xl)' }}>
            Join EduMaths and start teaching today
          </p>

          {/* Clerk Sign Up Component */}
          <SignUp
            routing="path"
            path="/signup"
            signInUrl="/login"
            fallbackRedirectUrl="/dashboard"
            appearance={{
              elements: {
                rootBox: {
                  width: '100%',
                },
                card: {
                  boxShadow: 'none',
                  border: 'none',
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default TeacherSignup;
