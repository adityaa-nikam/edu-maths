import express from 'express';
import cors from 'cors';
import { clerkMiddleware } from '@clerk/express';
import authRoutes from './routes/auth';
import academyRoutes from './routes/academy';
import studentRoutes from './routes/students';
import examRoutes from './routes/exams';
import teacherRoutes from './routes/teacher';

const app = express();

if (!process.env.CLERK_SECRET_KEY) {
  console.error('❌ CLERK_SECRET_KEY is missing from environment variables');
} else {
  console.log('✅ CLERK_SECRET_KEY is loaded');
}

if (!process.env.CLERK_PUBLISHABLE_KEY) {
  console.warn('⚠️ CLERK_PUBLISHABLE_KEY is missing from environment variables (client might fail)');
}


// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check route (no auth)
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    message: 'Server is running',
    timestamp: new Date().toISOString()
  });
});

// Public routes (no Clerk middleware needed)
app.use('/api/students', studentRoutes);
app.use('/api/exams', examRoutes);

// Teacher routes with Clerk middleware
// Apply Clerk middleware ONLY to teacher-specific routes
app.use('/api/auth', clerkMiddleware(), authRoutes);
app.use('/api/academy', clerkMiddleware(), academyRoutes);
app.use('/api/teacher', clerkMiddleware(), teacherRoutes);

export default app;
