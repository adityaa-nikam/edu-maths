# 🚀 **Quick Start: Dev Auth Bypass**

## ⚡ **1-Minute Setup**

### Step 1: Backend

Add to `backend/.env`:

```bash
DEV_AUTH_BYPASS=true
DEV_TEACHER_CLERK_ID=user_2qmAbcXyz123
DEV_STUDENT_ID=YOUR_REAL_STUDENT_UUID
DEV_ACADEMY_ID=YOUR_REAL_ACADEMY_UUID
```

**Get Real IDs**:
```sql
SELECT id FROM academies LIMIT 1;
SELECT id FROM students LIMIT 1;
SELECT clerk_user_id FROM academies LIMIT 1;
```

### Step 2: Frontend

Create `my-react-app/.env`:

```bash
VITE_API_URL=http://localhost:3000/api
VITE_DEV_AUTH_BYPASS=true
```

### Step 3: Restart Servers

```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend
cd my-react-app
npm run dev
```

**Look for console output**:
```
⚠️  DEV_AUTH_BYPASS enabled - using fake teacher identity
⚠️  DEV_AUTH_BYPASS enabled - using fake student identity
```

---

## ✅ **Test It**

**Student Exam (No Login)**:
```
http://localhost:5173/your-academy-slug/exam/exam-id
```

**Teacher Dashboard (No Login)**:
```
http://localhost:5173/your-academy-slug/dashboard
```

---

## ⚠️ **Before Production**

```bash
# Set in both .env files:
DEV_AUTH_BYPASS=false

# Or delete the lines entirely
```

---

**That's it!** Read `DEV_AUTH_BYPASS.md` for full details.
