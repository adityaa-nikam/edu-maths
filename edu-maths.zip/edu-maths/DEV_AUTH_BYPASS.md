# 🔧 **DEV AUTH BYPASS - Development Mode Authentication**

> ❗ **THIS FEATURE IS FOR LOCAL DEVELOPMENT ONLY**  
> Never enable this in production environments!

**Date**: 2026-01-08  
**Purpose**: Test complete exam flow without Clerk/JWT authentication  
**Status**: ✅ **IMPLEMENTED & SAFE**

---

## 🎯 **What This Is**

**Dev Auth Bypass** allows you to:
- ✅ Test the **complete exam system** without logging in
- ✅ Skip Clerk teacher authentication
- ✅ Skip Student JWT authentication
- ✅ Test all APIs, features, and workflows
- ✅ Use **real database records** (not fake data)

**This is NOT hacking - this is professional development practice!**

Every serious backend team uses auth bypass for:
- Local development
- Integration testing
- E2E testing
- CI/CD pipelines

---

## 🏗️ **How It Works**

### The Concept

```
Normal Flow:
  Frontend → Send JWT → Backend → Verify JWT → Execute Logic

Dev Mode:
  Frontend → No JWT → Backend → Inject Fake Identity → Execute Logic
                                        ↑
                                 (You're pretending to be authenticated)
```

**All business logic remains untouched!**

---

## 📁 **Files Modified**

### Backend (3 files)

| File | Changes |
|------|---------|
| `backend/src/middlewares/auth.ts` | Added DEV_AUTH_BYPASS logic to both middlewares |
| `backend/.env.example` | Documented new environment variables |
| `backend/.env` | **YOU MUST ADD** the flags manually |

### Frontend (3 files)

| File | Changes |
|------|---------|
| `my-react-app/src/exam/ExamPage.jsx` | Skip JWT check in dev mode |
| `my-react-app/src/utils/axios.js` | Don't require token in dev mode |
| `my-react-app/.env.example` | Documented VITE_DEV_AUTH_BYPASS flag |

---

## ⚙️ **Setup Instructions**

### Step 1: Backend Environment Variables

Edit `backend/.env` and add:

```bash
# Enable dev auth bypass
DEV_AUTH_BYPASS=true

# Fake identity IDs (MUST match real database records!)
DEV_TEACHER_CLERK_ID=user_2qmAbcXyz123      # Your teacher's Clerk user ID
DEV_STUDENT_ID=550e8400-e29b-41d4-a716-446655440000   # A real student UUID
DEV_ACADEMY_ID=550e8400-e29b-41d4-a716-446655440001   # A real academy UUID
```

⚠️ **CRITICAL**: The IDs **must exist** in your database!

---

### Step 2: Get Real Database IDs

#### **Option A: Query Your Database**

```sql
-- Get a real academy ID
SELECT id, name, slug FROM academies LIMIT 1;

-- Get the teacher's Clerk ID for that academy
SELECT clerk_user_id FROM academies WHERE id = 'your-academy-id';

-- Get a real student ID from that academy
SELECT id, username FROM students WHERE academy_id = 'your-academy-id' LIMIT 1;
```

#### **Option B: Use Existing Test Data**

If you created test data during development, use those IDs.

#### **Option C: Create Dev Test Records**

```sql
-- You likely already have these from previous testing
-- Just find their UUIDs
```

---

### Step 3: Frontend Environment Variables

Create or edit `my-react-app/.env`:

```bash
# Backend API URL
VITE_API_URL=http://localhost:3000/api

# Enable frontend auth bypass
VITE_DEV_AUTH_BYPASS=true
```

---

### Step 4: Restart Backend Server

The backend reads `.env` on startup:

```bash
cd backend
npm run dev
```

You should see in console:
```
⚠️  DEV_AUTH_BYPASS enabled - using fake teacher identity
⚠️  DEV_AUTH_BYPASS enabled - using fake student identity
```

---

### Step 5: Restart Frontend

Vite also reads env vars on startup:

```bash
cd my-react-app
npm run dev
```

---

## 🧪 **Testing the Flow**

### Test 1: Student Exam Flow

**Without logging in:**

1. Navigate to academy page:
   ```
   http://localhost:5173/your-academy-slug
   ```

2. Click "Take Exam" on any exam

3. **Should work!** You'll see:
   - BEFORE phase (exam info)
   - Start Exam button
   - DURING phase (questions, timer)
   - AFTER phase (results)

**No login required!** ✅

---

### Test 2: Teacher Dashboard

**Without logging in:**

1. Navigate directly to dashboard:
   ```
   http://localhost:5173/your-academy-slug/dashboard
   ```

2. **Should work!** You'll see:
   - All exams for the academy
   - Create exam form
   - Stats and filters

---

### Test 3: Teacher Results View

1. From dashboard, click an exam
   ```
   http://localhost:5173/your-academy-slug/dashboard/exams/:examId
   ```

2. See monitoring page with all attempts

3. Click "View Details" on a student

4. See question-by-question breakdown

**All working without login!** ✅

---

## 🔍 **How Each File Works**

### Backend: `auth.ts` (Teacher Middleware)

```typescript
export const authenticateTeacher = (req, res, next) => {
  // 🔧 DEV MODE
  if (process.env.DEV_AUTH_BYPASS === 'true') {
    req.clerkUserId = process.env.DEV_TEACHER_CLERK_ID;
    return next();  // ← Skip Clerk verification
  }

  // PRODUCTION
  const auth = req.auth();  // ← Normal Clerk flow
  if (!auth || !auth.userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  req.clerkUserId = auth.userId;
  next();
};
```

**Result**: Teacher routes work without Clerk login!

---

### Backend: `auth.ts` (Student Middleware)

```typescript
export const authenticateStudent = (req, res, next) => {
  // 🔧 DEV MODE
  if (process.env.DEV_AUTH_BYPASS === 'true') {
    req.studentId = process.env.DEV_STUDENT_ID;
    req.academyId = process.env.DEV_ACADEMY_ID;
    return next();  // ← Skip JWT verification
  }

  // PRODUCTION
  const token = req.headers.authorization?.split(' ')[1];
  const payload = verifyStudentToken(token);  // ← Normal JWT flow
  req.studentId = payload.studentId;
  req.academyId = payload.academyId;
  next();
};
```

**Result**: Student routes work without JWT!

---

### Frontend: `ExamPage.jsx`

```jsx
useEffect(() => {
  // 🔧 DEV MODE
  if (import.meta.env.VITE_DEV_AUTH_BYPASS === 'true') {
    setIsAuthenticated(true);
    return;  // ← Skip token check
  }

  // PRODUCTION
  const token = authStorage.getToken();
  if (!token) {
    navigate('/login');  // ← Normal redirect
    return;
  }
  setIsAuthenticated(true);
}, []);
```

**Result**: Exam page loads without redirect!

---

### Frontend: `axios.js`

```javascript
api.interceptors.request.use((config) => {
  // 🔧 DEV MODE
  if (import.meta.env.VITE_DEV_AUTH_BYPASS === 'true') {
    return config;  // ← Don't add token
  }

  // PRODUCTION
  const token = localStorage.getItem('studentToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

**Result**: API calls work without tokens!

---

## ✅ **What Still Works**

| Feature | Status |
|---------|--------|
| **Exam start** | ✅ Works |
| **Timer countdown** | ✅ Works |
| **Question navigation** | ✅ Works |
| **Autosave answers** | ✅ Works |
| **Submit exam** | ✅ Works |
| **Score calculation** | ✅ Works |
| **Teacher monitoring** | ✅ Works |
| **Student details** | ✅ Works |
| **Create exam** | ✅ Works |
| **Academy isolation** | ✅ Still enforced! |

**Everything works except authentication!**

---

## 🔐 **Security: What's Still Enforced**

### ✅ Academy Isolation

Even in dev mode, backend still checks:

```typescript
// This still runs!
if (targetStudent.academyId !== targetExam.academyId) {
  return res.status(403).json({ error: 'Forbidden' });
}
```

**Why?** Because you inject ONE fake academy ID. The business logic still validates it!

### ✅ Database Constraints

- ✅ Unique attempt per student
- ✅ Question locking
- ✅ Score calculations
- ✅ Submission timestamps

**All intact!**

---

## ⚠️ **CRITICAL: Production Safety**

### Before Deploying to Production

**YOU MUST**:

1. **Edit `backend/.env`**:
   ```bash
   DEV_AUTH_BYPASS=false  # ← CRITICAL!
   ```

2. **Edit `my-react-app/.env`**:
   ```bash
   VITE_DEV_AUTH_BYPASS=false  # ← CRITICAL!
   ```

3. **Or simply delete these lines**

4. **Restart servers**

5. **Test that login is required again**

---

### Deployment Checklist

```bash
# ✅ Before deploying:
grep -r "DEV_AUTH_BYPASS=true" .env
  → Should return NO results

# ✅ Verify login works:
Visit app → Should redirect to login
Try API call → Should return 401

# ✅ Only then deploy
```

---

## 🧠 **Why This Is Safe**

### ✅ Environment-Based

- Bypass is **OFF by default**
- Only works when explicitly enabled
- Production `.env` should never have it

### ✅ Code Is Unchanged

```typescript
// We ADDED this block:
if (process.env.DEV_AUTH_BYPASS === 'true') {
  // bypass logic
}

// Original code is still here:
const auth = req.auth();
// ... normal auth flow
```

**Original logic is untouched!**

### ✅ Reversible in 1 Second

Set `DEV_AUTH_BYPASS=false` → Everything back to normal

---

## 📊 **Request Flow Comparison**

### Production Flow

```
Student → Frontend
           ↓ (POST /login)
         Backend validates credentials
           ↓
         Returns JWT
           ↓
Student → Frontend stores JWT
           ↓ (GET /exam with JWT)
         Backend verifies JWT
           ↓
         Returns exam data
```

### Dev Mode Flow

```
Student → Frontend
           ↓ (GET /exam, NO JWT)
         Backend sees DEV_AUTH_BYPASS=true
           ↓
         Injects fake studentId/academyId
           ↓
         Returns exam data
           ↓
         (same result, skipped auth)
```

---

## 🎓 **Common Use Cases**

### 1. Testing Timer Logic

No need to log in every time:
```bash
# Just visit:
http://localhost:5173/academy/exam/exam-id

# Timer starts immediately
# Test expiry, auto-submit, etc.
```

### 2. Testing Teacher Dashboard

```bash
# Direct access:
http://localhost:5173/academy/dashboard

# Create exams
# View results
# No Clerk login needed
```

### 3. Integration Testing

```bash
# Your test scripts can call APIs directly:
curl http://localhost:3000/api/exams/:id/start

# No auth headers needed
# Backend injects identity
```

### 4. Frontend Development

- ✅ Focus on UI/UX
- ✅ No token management
- ✅ Faster iteration

---

## 🔧 **Troubleshooting**

### Problem: APIs Return 401

**Solution**: Check backend console for:
```
⚠️  DEV_AUTH_BYPASS enabled - using fake teacher identity
```

If you don't see this:
1. Verify `DEV_AUTH_BYPASS=true` in `backend/.env`
2. Restart backend server
3. Check there's no typo in the variable name

---

### Problem: Database Errors

**Error**: `Student not found`

**Solution**: Your `DEV_STUDENT_ID` doesn't exist in database!

```sql
-- Find a real student ID:
SELECT id FROM students LIMIT 1;

-- Update your .env:
DEV_STUDENT_ID=<real-uuid-from-above>
```

---

### Problem: Frontend Still Redirects

**Solution**: Check frontend console for:
```
⚠️  DEV_AUTH_BYPASS enabled - skipping student login check
```

If you don't see this:
1. Verify `VITE_DEV_AUTH_BYPASS=true` in `my-react-app/.env`
2. Restart frontend dev server (**IMPORTANT**)
3. Hard refresh browser (Ctrl+Shift+R)

---

### Problem: Exam Doesn't Load

**Possible Causes**:

1. **Wrong academy slug in URL**
   ```
   ❌ http://localhost:5173/wrong-slug/exam/id
   ✅ http://localhost:5173/correct-slug/exam/id
   ```

2. **Exam doesn't belong to dev academy**
   ```sql
   -- Check:
   SELECT * FROM exams WHERE academy_id = 'your-dev-academy-id';
   ```

3. **Dev Academy ID mismatch**
   ```
   Backend uses: academy-id-1
   Database has: academy-id-2
   
   → Update .env to match database
   ```

---

## 📝 **Quick Reference**

### Enable Dev Mode

```bash
# Backend .env
DEV_AUTH_BYPASS=true
DEV_TEACHER_CLERK_ID=user_abc123
DEV_STUDENT_ID=uuid-1
DEV_ACADEMY_ID=uuid-2

# Frontend .env
VITE_DEV_AUTH_BYPASS=true

# Restart both servers!
```

### Disable Dev Mode

```bash
# Backend .env
DEV_AUTH_BYPASS=false  # or delete line

# Frontend .env
VITE_DEV_AUTH_BYPASS=false  # or delete line

# Restart both servers!
```

### Verify It's Working

```bash
# Backend console should show:
⚠️  DEV_AUTH_BYPASS enabled - using fake teacher identity

# Frontend console should show:
⚠️  DEV_AUTH_BYPASS enabled - skipping student login check

# Browser network tab:
Requests go through WITHOUT Authorization header
```

---

## 🎯 **Summary**

### What We Did

✅ **Backend**: Modified auth middlewares to inject fake identity  
✅ **Frontend**: Skip login redirects and token checks  
✅ **Safe**: Original code untouched, easily reversible  
✅ **Environment-based**: Only works when explicitly enabled

### What You Can Do Now

✅ Test complete exam flow without logging in  
✅ Develop UI faster (no constant re-login)  
✅ Run integration tests easily  
✅ Demo features to stakeholders quickly

### What You Must Remember

⚠️ **NEVER deploy with `DEV_AUTH_BYPASS=true`**  
⚠️ Always test that auth still works before deploying  
⚠️ Use real database IDs, not fake ones

---

**This is professional development practice!** ✅

Every serious SaaS team uses auth bypass for local development!

---

**End of Dev Auth Bypass Documentation** 🔧✨
